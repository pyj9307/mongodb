# SpringBoot_MongoDB_Connect_Test
SpringBoot_MongoDB_Connect_Test
org.springframework.boot' version '2.7.8'
java 17
mongodb docker 6.0.4

간단한 스프링 부트 몽고 디비 연동 테스트 프로젝트.
뷰에서 이미지, 동영상, 일반글 , 간단한 ODM 기술을 통해서 테스트중 입니다.
필요하신 분든 참고하세요. 

이걸 기반으로 미니 인프런 프로젝트도 할 예정입니다.
작업 후, 소스 공개할 예정입니다. 
