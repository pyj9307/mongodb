package com.myMongoTest.constant;

public enum Role {
    USER, ADMIN
}