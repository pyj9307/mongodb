package com.myMongoTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMongoDbConnectTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
